$(function () {
    $('.table').DataTable()
})