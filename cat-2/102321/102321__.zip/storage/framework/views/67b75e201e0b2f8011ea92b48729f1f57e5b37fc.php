<!DOCTYPE html>
<html>

<head>
    <title>Fee</title>
    <?php echo $__env->make('links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('Jerry.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="row mt-3">
            <div class="col-sm-3 col-md-3"></div>
            <div class="col-xs-12 col-sm-6 col-md-6">
                <div class="card">
                    <div class="card-heading">
                        <h3 class="card-title mt-2" align="center" style="font-size: 20px;">Fees Deposit Form</h3>
                    </div>

                    <div class="card-body">
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                            <?php
                            Session::forget('success');
                            ?>
                        </div>
                        <?php endif; ?>
                        <form role="form" method="post" accept="/feedeposit">
                            <?php echo e(csrf_field()); ?>


                            <br>
                            <div class="form-group">
                                <input style="font-size: 16px;" type="text" name="student_no" id="student_no"
                                    class="form-control input-sm" placeholder="Student Number">
                                <?php if($errors->has('student_no')): ?><span
                                    class="text-danger"><?php echo e($errors->first('student_no')); ?></span>
                                <?php endif; ?>
                            </div>

                            <br>
                            <div class="form-group">
                                <input style="font-size: 16px;" type="text" name="amount" id="address"
                                    class="form-control input-sm" placeholder="Payment Amount">
                                <?php if($errors->has('amount')): ?><span
                                    class="text-danger"><?php echo e($errors->first('amount')); ?></span>
                                <?php endif; ?>
                            </div>


                            <br>
                            <div class="form-group">
                                <label>Date of Payment</label>
                                <input style="font-size: 16px;" type="Date" name="paid_at" id="paid_at"
                                    class="form-control input-sm" placeholder="Date of Birth">
                                <?php if($errors->has('paid_at')): ?><span
                                    class="text-danger"><?php echo e($errors->first('paid_at')); ?></span>
                                <?php endif; ?>
                            </div>

                            <br><input type="submit" style="font-size: 18px;" value="Deposit"
                                class="btn btn-outline-primary btn-block">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body><?php /**PATH C:\xampp\htdocs\labs\cat-2\102321\resources\views/Jerry/fees.blade.php ENDPATH**/ ?>