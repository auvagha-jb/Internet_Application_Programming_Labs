 
<?php $__env->startSection('content'); ?>
	<?php if(count($fees) > 0): ?>
		<h2>Search Results</h2>
		<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<h2 class="page-header text-center">Student AMS</h2>
		<h4>Fee Records</h4>
		<table class="table table-bordered table-striped">
			<thead>
				
				<th>Student Number</th>
				<th>Amount</th>
				<th>Payment Date</th>
				
			</thead>
			<tbody>
				<?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						
						<td><?php echo e($fee->student_no); ?></td>
						<td><?php echo e($fee->amount); ?></td>
						<td><?php echo e($fee->paid_at); ?></td>
						
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
	<?php else: ?>
		<h2>No Results Found</h2>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Amos.Feecheck', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\catprac\resources\views/Amos/searchresult.blade.php ENDPATH**/ ?>