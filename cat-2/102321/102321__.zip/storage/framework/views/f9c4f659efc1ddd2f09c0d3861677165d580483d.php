<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Students</title>
    <?php echo $__env->make('links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('Jerry.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(count($students) > 0): ?>
    <div class="row p-3">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <center class="lead">
                <h2>Students</h2>
            </center>
            <table class="table table-bordered table-striped">
                <thead class="thead-dark">
                    <th>Student Number</th>
                    <th>Name</th>
                    <th>Date of Birth</th>
                    <th>Address</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($student->student_no); ?></td>
                        <td><?php echo e($student->first_name." ".$student->last_name); ?></td>
                        <td><?php echo e($student->date_of_birth); ?></td>
                        <td><?php echo e($student->address); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php else: ?>
    <center class="lead">No students registered</center>
    <?php endif; ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\labs\cat-2\102321\resources\views/Jerry/allStudents.blade.php ENDPATH**/ ?>