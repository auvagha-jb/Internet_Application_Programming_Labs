 
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<h2 class="page-header text-center">Student AMS</h2>
		<h4>Fee Records</h4>
		<table class="table table-bordered table-striped">
			<thead>
				
				<th>Student Number</th>
				<th>Amount</th>
				
			</thead>
			<tbody>
				<?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($fee->student_no); ?></td>
						<td><?php echo e($fee->amount); ?></td>

						
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<tr>
					<td style="font-size: 18px;"><strong>Total</strong></td>
					<td style="font-size: 18px;"><b><?php echo e($total); ?></b></td>
				</tr>
			</tbody>

		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Amos.Feecheck', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\100636\resources\views/Amos/search.blade.php ENDPATH**/ ?>