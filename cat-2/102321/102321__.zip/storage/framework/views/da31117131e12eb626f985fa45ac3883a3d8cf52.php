<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand btn btn-primary" href="#">AMS</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
        aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item active p-2">
                <a style="text-decoration: none; font-size: 18px;" href="<?php echo e(url('/')); ?>">Home</a>
            </li>
            <li class="nav-item p-2">
                <a style="text-decoration: none; font-size: 18px;" href="<?php echo e(route('student')); ?>">Register</a>
            </li>
            <li class="nav-item p-2">
                <a style="text-decoration: none; font-size: 18px;" href="<?php echo e(url('all/students/')); ?>">Students</a>
            </li>
            <li class="nav-item p-2">
                <a style="text-decoration: none; font-size: 18px;" href="<?php echo e(route('fees')); ?>">Fee Deposit</a>
            </li>
            <li class="nav-item p-2">
                <a style="text-decoration: none; font-size: 18px;" href="<?php echo e(route('paid')); ?>">Payments</a>
            </li>
        </ul>
    </div>

</nav><?php /**PATH C:\xampp\htdocs\labs\cat-2\102321\resources\views/Jerry/navbar.blade.php ENDPATH**/ ?>