<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Search</title>
    <?php echo $__env->make('links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('Jerry.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-xs-12 col-sm-12 col-md-4">
            <form style="margin-left: 400px; width: 300px;" action="<?php echo e(URL::to('find')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="input-group p-3">
                    <input type="text" id="search" name="search" class="form-control"
                        placeholder="Search payment history">
                    <span class="input-group-append">
                        <button type="submit" class="btn btn-primary">
                            <span class="fa fa-search"></span>
                        </button>
                    </span>
                </div>
            </form>
        </div>
    </div>

    <div id="result" class="panel panel-default"
        style="width:400px; position:absolute; left:180px; top:55px; z-index:1; display:none">
        <ul style="margin-top:10px; list-style-type:none;" id="memList">

        </ul>
    </div>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>

    </div>
    <script type="text/javascript">
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#search').keyup(function() {
            var search = $('#search').val();
            if (search == "") {
                $("#feeList").html("");
                $('#result').hide();
            } else {
                $.get("<?php echo e(URL::to('search')); ?>", {
                    search: search
                }, function(data) {
                    $('#feeList').empty().html(data);
                    $('#result').show();
                })
            }
        });
    });
    </script>
</body>

</html><?php /**PATH C:\xampp\htdocs\labs\cat-2\102321\resources\views/Jerry/Feecheck.blade.php ENDPATH**/ ?>