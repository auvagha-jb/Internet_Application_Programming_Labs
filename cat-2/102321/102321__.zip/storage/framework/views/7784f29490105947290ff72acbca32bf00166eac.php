<?php if(count($fees) > 0): ?>
	<?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><?php echo e(url('find/'.$fee->id)); ?> <?php echo e($fee->student_no); ?> <?php echo e($fee->amount); ?> <?php echo e($fee->paid_at); ?></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
	<li style="text-align: center;">No Results Found</li>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\labs\cat-2\102321\resources\views/Jerry/result.blade.php ENDPATH**/ ?>