<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/app.css')); ?>">
    <title>All cars</title>
</head>

<body>
    <?php echo $__env->make('helpers.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="row pt-3">
        <div class="col-3"></div>
        <div class="col-6">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <td>Make</td>
                        <td>Model</td>
                        <td>Review</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($review->make); ?></td>
                        <td><?php echo e($review->model); ?></td>
                        <td><?php echo e($review->review); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\labs\laravel-labs\app_\resources\views/cars/fetchReviewedCar.blade.php ENDPATH**/ ?>